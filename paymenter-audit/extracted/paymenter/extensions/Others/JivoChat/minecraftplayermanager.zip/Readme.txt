Thank you for buying the Minecraft Player Manager for Calagopus!

For install instructions, view https://calagopus.com/docs/panel/extensions/installing-extensions
